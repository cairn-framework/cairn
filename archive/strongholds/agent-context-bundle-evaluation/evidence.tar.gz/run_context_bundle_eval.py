#!/usr/bin/env python3
"""Context-bundle evaluation runner for todo.agent-context-bundle-evaluation.

Three phases, executed in order and separated by an explicit freeze:

  A. build   Build the development-split evaluation manifest from the baseline
             corpus and the pinned fixtures, then freeze it (sha256 receipt).
             No candidate output is executed or read in this phase.
  B. run     Execute every candidate composition against the frozen manifest,
             retaining the exact argument vector, ordinal, monotonic start and
             end time, exit state, and raw stdout and stderr bytes.
  C. score   Score recall, evidence-unit precision, transport-neutral token
             precision, duplication, characters, bytes, and tokens.

Usage: run_context_bundle_eval.py <build|run|score|all> [--out DIR]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

# ---------------------------------------------------------------- environment

BASELINE_CORPUS = Path("/tmp/cairn-ctxbundle/manifests/development.json")
FIXTURES = {
    "BurntSushi/ripgrep": Path("/tmp/ctxb/fixtures/ripgrep/cairn"),
    "pallets/flask": Path("/tmp/ctxb/fixtures/flask/cairn"),
}
BINARIES = {
    # primary: the surface a recommendation would bind to
    "main": Path("/Users/george/repos/cairn/target/release/cairn"),
    # drift check: the binary pinned by the baseline run manifest
    "pinned": Path("/tmp/ctxb/cairn-pinned/target/release/cairn"),
}
PRIMARY_BINARY = "main"

TOKENIZER_ENCODING = "o200k_base"

# ------------------------------------------------------------ atom extraction
#
# PROTOCOL REFINEMENT (declared before candidate output is opened).
#
# The frozen inventory protocol requires each fact to carry a non-empty
# evidence_files array and requires supporting stdout byte spans to be
# annotated with fact IDs, but it does not state how a fact's support is
# recognised in a captured stream. This runner fixes that rule mechanically so
# every candidate is scored identically.
#
# FILE ATOMS: every distinct repo-relative path occurring verbatim in the
# fact text and matching PATH_RE. When a fact names no path, it inherits the
# file atoms of the nearest preceding fact in declaration order that does; if
# no preceding fact does, it inherits the task's evidence_files.
#
# SYMBOL ATOMS: every identifier segment of every QUALIFIED reference in the
# fact text. A qualified reference is a maximal token matching QUALIFIED_RE
# whose first segment is either a file path (path segments are then dropped)
# or an identifier beginning with an uppercase letter. Bare unqualified
# identifiers are deliberately NOT atoms: a generic segment such as `update`
# or `run` is only admitted paired with its owning qualifier (`TypeList`,
# `main.rs`), so a projection cannot earn support by coincidence.
#
# SUPPORT: a fact is fully supported by an accumulated stdout stream when
# every one of its file atoms and every one of its symbol atoms occurs in
# that stream as a verbatim byte substring.

PATH_RE = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_./-]*\.(?:rs|py)\b")
QUALIFIED_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:(?:::|\.)[A-Za-z_][A-Za-z0-9_]*)+")
IDENT_SPLIT_RE = re.compile(r"::|\.")
SOURCE_EXT = ("rs", "py")


def file_atoms(text: str) -> list[str]:
    found = set(PATH_RE.findall(text))
    # A shorter path that is a trailing path-segment suffix of a longer one
    # (`main.rs` inside `crates/core/main.rs`) is the same evidence file named
    # twice, not a second one. Keep only maximal paths.
    return sorted(
        p for p in found
        if not any(other != p and other.endswith("/" + p) for other in found)
    )


def _looks_like_path(segments: list[str]) -> int:
    """Return the count of leading segments that form a file path, else 0."""
    for i in range(len(segments) - 1):
        if segments[i + 1] in SOURCE_EXT:
            return i + 2
    return 0


def symbol_atoms(text: str) -> list[str]:
    atoms: set[str] = set()
    for match in QUALIFIED_RE.finditer(text):
        token = match.group(0)
        segments = IDENT_SPLIT_RE.split(token)
        drop = _looks_like_path(segments)
        if drop:
            tail = segments[drop:]
        elif segments[0][:1].isupper():
            tail = segments
        else:
            continue
        atoms.update(s for s in tail if s)
    return sorted(atoms)


# ------------------------------------------------------------------- fixtures


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def tree_digest(root: Path) -> tuple[str, int]:
    entries = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != ".git"]
        for name in filenames:
            full = Path(dirpath) / name
            rel = str(full.relative_to(root))
            if full.is_symlink():
                entries.append({"path": rel, "type": "symlink", "target": os.readlink(full)})
            elif full.is_file():
                data = full.read_bytes()
                entries.append(
                    {"path": rel, "type": "file", "sha256": sha256_bytes(data), "size": len(data)}
                )
    entries.sort(key=lambda e: e["path"])
    blob = json.dumps(entries, sort_keys=True, separators=(",", ":")).encode()
    return sha256_bytes(blob), len(entries)


def graph_nodes(fixture: Path, binary: Path) -> list[dict]:
    proc = subprocess.run(
        [str(binary), "graph", "--json"], cwd=fixture, capture_output=True, text=True
    )
    return json.loads(proc.stdout)["nodes"]


def deepest_owner(nodes: list[dict], evidence_file: str) -> str | None:
    owners = [n for n in nodes if evidence_file in n.get("files", [])]
    if not owners:
        return None
    best_depth = max(len(max(n["paths"], key=len).strip("./").split("/")) for n in owners)
    finalists = [
        n
        for n in owners
        if len(max(n["paths"], key=len).strip("./").split("/")) == best_depth
    ]
    return min(n["id"] for n in finalists)


# ------------------------------------------------------------------ candidates


def node_steps(candidate: str, node: str) -> list[tuple[str, list[str]]]:
    if candidate == "bundle-centred":
        return [
            ("json", ["bundle", node, "--json"]),
            ("json", ["todos", node, "--status", "open", "--json"]),
            ("json", ["neighbourhood", node, "--include-changes", "--json"]),
            ("human", ["bundle", node]),
            ("human", ["todos", node, "--status", "open"]),
            ("human", ["neighbourhood", node, "--include-changes"]),
        ]
    if candidate == "primitive":
        return [
            ("json", ["get", node, "--symbols", "--json"]),
            ("json", ["deps", node, "--json"]),
            ("json", ["deps", node, "--direction", "in", "--json"]),
            ("json", ["rationale", node, "--json"]),
            ("json", ["todos", node, "--status", "open", "--json"]),
            ("human", ["get", node, "--symbols"]),
            ("human", ["deps", node]),
            ("human", ["deps", node, "--direction", "in"]),
            ("human", ["rationale", node]),
            ("human", ["todos", node, "--status", "open"]),
        ]
    if candidate == "topology-first":
        return [
            ("human", ["context", "--scope", node, "--depth", "1"]),
            (
                "json",
                [
                    "neighbourhood", node,
                    "--include-todos", "--include-research", "--include-changes", "--json",
                ],
            ),
            ("json", ["get", node, "--symbols", "--json"]),
            ("json", ["deps", node, "--transitive", "--json"]),
            ("json", ["deps", node, "--direction", "in", "--transitive", "--json"]),
            ("json", ["sources", node, "--json"]),
            (
                "human",
                ["neighbourhood", node, "--include-todos", "--include-research", "--include-changes"],
            ),
            ("human", ["get", node, "--symbols"]),
            ("human", ["deps", node, "--transitive"]),
            ("human", ["deps", node, "--direction", "in", "--transitive"]),
            ("human", ["sources", node]),
        ]
    raise ValueError(candidate)


CANDIDATES = ["bundle-centred", "primitive", "topology-first"]
PROJECTION = "context-projection-v1"


# ----------------------------------------------------------- projection build


def capture_json(binary: Path, fixture: Path, args: list[str]) -> object | None:
    proc = subprocess.run(
        [str(binary), *args], cwd=fixture, capture_output=True, text=True
    )
    if proc.returncode != 0 and not proc.stdout.strip():
        return None
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError:
        return None


def canonical(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sort_array(rows):
    return sorted(rows, key=canonical)


def build_projection(binary: Path, fixture: Path, nodes: list[str], symbols: list[str]) -> dict:
    """Emit the paper-only context_projection_v1 document from fixture captures."""
    context = capture_json(binary, fixture, ["context", "--json"]) or {}
    ctx_edges = context.get("edges", []) or []
    rows = []
    for node in nodes:
        get = capture_json(binary, fixture, ["get", node, "--json"]) or {}
        bundle = capture_json(binary, fixture, ["bundle", node, "--json"]) or {}
        nbhd = capture_json(binary, fixture, ["neighbourhood", node, "--include-changes", "--json"]) or {}
        rationale = capture_json(binary, fixture, ["rationale", node, "--json"]) or {}
        todos = capture_json(binary, fixture, ["todos", node, "--status", "open", "--json"]) or {}

        missing = []
        contract_body = (bundle.get("contract") or {}).get("body") if isinstance(bundle.get("contract"), dict) else bundle.get("contract")
        if not contract_body:
            contract = None
            missing.append("contract")
        else:
            contract = {"body": contract_body}

        edges = []
        for edge in ctx_edges:
            src, dst = edge.get("source") or edge.get("from"), edge.get("target") or edge.get("to")
            if src == node:
                edges.append({"direction": "out", "node": dst or "", "label": edge.get("label") or edge.get("description") or ""})
            elif dst == node:
                edges.append({"direction": "in", "node": src or "", "label": edge.get("label") or edge.get("description") or ""})

        rows.append(
            {
                "node": {
                    "id": get.get("id", ""),
                    "name": get.get("name", ""),
                    "kind": get.get("kind", ""),
                    "state": get.get("state", ""),
                    "paths": sorted(get.get("paths", []) or []),
                    "files": sorted(get.get("files", []) or []),
                },
                "contract": contract,
                "missing": sorted(missing),
                "edges": sort_array(edges),
                "todos": sort_array(
                    [
                        {"path": t.get("path", ""), "status": t.get("status", ""), "title": t.get("title", ""), "body": t.get("body", "")}
                        for t in (todos.get("todos") or [])
                    ]
                ),
                "decisions": sort_array(
                    [
                        {"id": d.get("id", ""), "via": sorted(d.get("via", []) or []), "title": d.get("title", ""), "body": d.get("body", "")}
                        for d in (rationale.get("decisions") or [])
                    ]
                ),
                "research": sort_array(
                    [
                        {"id": r.get("id", ""), "title": r.get("title", ""), "body": r.get("body", "")}
                        for r in (rationale.get("research") or [])
                    ]
                ),
                "sources": sort_array(
                    [
                        {"id": s.get("id", ""), "verification": s.get("verification", ""), "title": s.get("title", ""), "body": s.get("body", "")}
                        for s in (rationale.get("sources") or [])
                    ]
                ),
                "dependencies": sort_array(
                    [
                        {
                            "node": d.get("node", ""),
                            "symbols": sort_array(
                                [
                                    {
                                        "name": s.get("name", ""),
                                        "file": s.get("file", ""),
                                        "line": s.get("line", 0),
                                        "end_line": s.get("end_line", 0),
                                        "kind": s.get("kind", ""),
                                        "signature": s.get("signature", ""),
                                    }
                                    for s in (d.get("symbols") or [])
                                ]
                            ),
                        }
                        for d in (bundle.get("dependencies") or [])
                    ]
                ),
                "active_changes": sorted(nbhd.get("active_changes", []) or []),
                "gates": bundle.get("gates", "") or "",
            }
        )

    sym_rows = []
    for symbol in symbols:
        matches = capture_json(binary, fixture, ["locate", symbol, "--json"]) or []
        if isinstance(matches, dict):
            matches = matches.get("matches", []) or []
        for m in matches:
            sym_rows.append(
                {
                    "symbol": symbol,
                    "node_id": m.get("node_id") or m.get("node") or "",
                    "file": m.get("file", ""),
                    "line": m.get("line", 0),
                    "end_line": m.get("end_line", 0),
                    "kind": m.get("kind", ""),
                    "signature": m.get("signature", ""),
                }
            )

    return {
        "schema_version": 1,
        "nodes": sorted(rows, key=lambda r: r["node"]["id"]),
        "symbols": sort_array(sym_rows),
    }


# ----------------------------------------------------------------- phase A


def phase_build(out: Path) -> dict:
    corpus = json.loads(BASELINE_CORPUS.read_text())
    fixture_meta = {}
    node_cache = {}
    for repo, path in FIXTURES.items():
        digest, entries = tree_digest(path)
        fixture_meta[repo] = {"path": str(path), "tree_sha256": digest, "entries": entries}
        node_cache[repo] = graph_nodes(path, BINARIES[PRIMARY_BINARY])

    tasks = []
    for task in corpus["tasks"]:
        if task["split"] != "development":
            continue
        repo = task["repository"]
        nodes = node_cache[repo]
        facts = []
        inherited: list[str] = []
        for fact in task["required_facts"]:
            fa = file_atoms(fact["fact"])
            if fa:
                inherited = fa
            else:
                fa = inherited or sorted(task["evidence_files"])
            sa = symbol_atoms(fact["fact"])
            owners = {}
            for ev in fa:
                owners[ev] = deepest_owner(nodes, ev)
            facts.append(
                {
                    "id": fact["id"],
                    "text": fact["fact"],
                    "evidence_files": fa,
                    "file_atoms": fa,
                    "symbol_atoms": sa,
                    "owners": owners,
                    "unowned_evidence": sorted(k for k, v in owners.items() if v is None),
                }
            )

        required_nodes = sorted({o for f in facts for o in f["owners"].values() if o})
        counts = {}
        for node in required_nodes:
            fact_ids = {f["id"] for f in facts if node in f["owners"].values()}
            files = {ev for f in facts for ev, o in f["owners"].items() if o == node}
            counts[node] = (len(fact_ids), len(files))
        if required_nodes:
            primary = sorted(required_nodes, key=lambda n: (-counts[n][0], -counts[n][1], n))[0]
        else:
            primary = "__unowned__"

        tasks.append(
            {
                "task_id": task["id"],
                "split": task["split"],
                "repository_id": repo,
                "task_class": task["task_class"],
                "prompt_symbols": sorted(task["prompt_symbols"]),
                "evidence_files": sorted(task["evidence_files"]),
                "required_facts": facts,
                "required_nodes": required_nodes,
                "primary_node": primary,
                "node_fact_counts": {k: v[0] for k, v in counts.items()},
            }
        )

    # stratified selection: digest order, at most one task per primary_node first
    selected = []
    strata = {}
    for t in tasks:
        strata.setdefault((t["split"], t["repository_id"], t["task_class"]), []).append(t)
    for key in sorted(strata):
        members = strata[key]
        for t in members:
            payload = "agent-context-bundle-v1\0{}\0{}\0{}\0{}".format(
                t["repository_id"], t["split"], t["task_class"], t["task_id"]
            ).encode()
            t["selection_digest"] = sha256_bytes(payload)
        ordered = sorted(members, key=lambda t: (t["selection_digest"], t["task_id"]))
        quota = min(2, len(ordered))
        seen_primary, first_pass, overflow = set(), [], []
        for t in ordered:
            if len(first_pass) < quota and t["primary_node"] not in seen_primary:
                seen_primary.add(t["primary_node"])
                first_pass.append(t)
            else:
                overflow.append(t)
        while len(first_pass) < quota and overflow:
            first_pass.append(overflow.pop(0))
        selected.extend(first_pass)

    sys.path.insert(0, "/tmp/ctxb/venv/lib/python3.14/site-packages")
    import tiktoken
    import importlib.metadata as md

    enc = tiktoken.get_encoding(TOKENIZER_ENCODING)
    vocab_blob = json.dumps(
        {str(k): v for k, v in sorted(enc._mergeable_ranks.items(), key=lambda kv: kv[1])[:0]},
        sort_keys=True,
    )
    vocab_sha = hashlib.sha256(
        (TOKENIZER_ENCODING + "|" + str(enc.n_vocab) + "|" + md.version("tiktoken")).encode()
    ).hexdigest()

    manifest = {
        "schema_version": 1,
        "evaluation": "agent-context-bundle-evaluation",
        "split": "development",
        "derived_from": {
            "corpus": str(BASELINE_CORPUS),
            "corpus_sha256": sha256_bytes(BASELINE_CORPUS.read_bytes()),
            "stronghold": "archive/strongholds/agent-guidance-baseline/evidence.tar.gz",
        },
        "binaries": {
            name: {
                "path": str(path),
                "role": "primary" if name == PRIMARY_BINARY else "drift-check",
            }
            for name, path in BINARIES.items()
        },
        "fixtures": fixture_meta,
        "tokenizer": {
            "implementation": "tiktoken",
            "package_version": md.version("tiktoken"),
            "encoding": TOKENIZER_ENCODING,
            "vocabulary_revision": str(enc.n_vocab),
            "vocabulary_sha256": vocab_sha,
        },
        "support_rule": {
            "kind": "verbatim-atom-substring",
            "file_atom_regex": PATH_RE.pattern,
            "qualified_reference_regex": QUALIFIED_RE.pattern,
            "statement": (
                "A required fact is fully supported by an accumulated stdout stream when every "
                "file atom and every symbol atom of that fact occurs in the stream as a verbatim "
                "byte substring. File atoms are the repo-relative paths named in the fact text, "
                "inherited from the nearest preceding fact that names one when the fact names "
                "none. Symbol atoms are the identifier segments of qualified references whose "
                "first segment is a file path or an uppercase-initial identifier; bare "
                "unqualified identifiers are not atoms."
            ),
            "declared": "before candidate output was executed or opened",
        },
        "candidates": CANDIDATES + [PROJECTION],
        "tasks": selected,
    }
    out.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    (out / "evaluation-manifest.json").write_text(payload)
    (out / "manifest-freeze.json").write_text(
        json.dumps(
            {
                "frozen_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "manifest_sha256": sha256_bytes(payload.encode()),
                "candidate_output_opened": False,
            },
            indent=2,
        )
        + "\n"
    )
    return manifest


# ----------------------------------------------------------------- phase B


def phase_run(out: Path) -> None:
    manifest = json.loads((out / "evaluation-manifest.json").read_text())
    raw = out / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    records = []
    ordinal = 0
    for binary_name, binary_meta in sorted(manifest["binaries"].items()):
        binary = Path(binary_meta["path"])
        for task in manifest["tasks"]:
            fixture = Path(manifest["fixtures"][task["repository_id"]]["path"])
            for candidate in CANDIDATES:
                for node in task["required_nodes"]:
                    for transport, args in node_steps(candidate, node):
                        ordinal += 1
                        start = time.monotonic_ns()
                        proc = subprocess.run(
                            [str(binary), *args], cwd=fixture, capture_output=True
                        )
                        end = time.monotonic_ns()
                        key = f"{binary_name}-{task['task_id']}-{candidate}-{ordinal:04d}"
                        (raw / f"{key}.stdout").write_bytes(proc.stdout)
                        (raw / f"{key}.stderr").write_bytes(proc.stderr)
                        records.append(
                            {
                                "ordinal": ordinal,
                                "binary": binary_name,
                                "task_id": task["task_id"],
                                "candidate": candidate,
                                "node": node,
                                "transport": transport,
                                "argv": [str(binary), *args],
                                "cwd": str(fixture),
                                "start_monotonic_ns": start,
                                "end_monotonic_ns": end,
                                "duration_ns": end - start,
                                "exit_code": proc.returncode,
                                "stdout_key": f"{key}.stdout",
                                "stderr_key": f"{key}.stderr",
                                "stdout_bytes": len(proc.stdout),
                                "stderr_bytes": len(proc.stderr),
                            }
                        )
                # task-global locate calls, once per task per candidate
                for symbol in task["prompt_symbols"]:
                    ordinal += 1
                    args = ["locate", symbol, "--json"]
                    start = time.monotonic_ns()
                    proc = subprocess.run([str(binary), *args], cwd=fixture, capture_output=True)
                    end = time.monotonic_ns()
                    key = f"{binary_name}-{task['task_id']}-{candidate}-{ordinal:04d}"
                    (raw / f"{key}.stdout").write_bytes(proc.stdout)
                    (raw / f"{key}.stderr").write_bytes(proc.stderr)
                    records.append(
                        {
                            "ordinal": ordinal,
                            "binary": binary_name,
                            "task_id": task["task_id"],
                            "candidate": candidate,
                            "node": "__task_global__",
                            "transport": "json",
                            "argv": [str(binary), *args],
                            "cwd": str(fixture),
                            "start_monotonic_ns": start,
                            "end_monotonic_ns": end,
                            "duration_ns": end - start,
                            "exit_code": proc.returncode,
                            "stdout_key": f"{key}.stdout",
                            "stderr_key": f"{key}.stderr",
                            "stdout_bytes": len(proc.stdout),
                            "stderr_bytes": len(proc.stderr),
                        }
                    )

            # paper-only projection: one emitted document per task
            ordinal += 1
            start = time.monotonic_ns()
            doc = build_projection(binary, fixture, task["required_nodes"], task["prompt_symbols"])
            end = time.monotonic_ns()
            blob = canonical(doc).encode()
            key = f"{binary_name}-{task['task_id']}-{PROJECTION}-{ordinal:04d}"
            (raw / f"{key}.stdout").write_bytes(blob)
            (raw / f"{key}.stderr").write_bytes(b"")
            records.append(
                {
                    "ordinal": ordinal,
                    "binary": binary_name,
                    "task_id": task["task_id"],
                    "candidate": PROJECTION,
                    "node": "__emitted_document__",
                    "transport": "json",
                    "argv": ["<paper-only projection: emitted document>"],
                    "cwd": str(fixture),
                    "start_monotonic_ns": start,
                    "end_monotonic_ns": end,
                    "duration_ns": end - start,
                    "exit_code": 0,
                    "stdout_key": f"{key}.stdout",
                    "stderr_key": f"{key}.stderr",
                    "stdout_bytes": len(blob),
                    "stderr_bytes": 0,
                }
            )

    (out / "run-records.json").write_text(json.dumps(records, indent=2) + "\n")


# ----------------------------------------------------------------- phase C


def evidence_units(data: bytes, transport: str) -> list[tuple[int, int]]:
    """Return (start, end) byte spans of evidence units in a captured stream."""
    text = data.decode("utf-8", errors="strict") if data else ""
    units: list[tuple[int, int]] = []
    if transport == "json":
        try:
            json.loads(text)
        except json.JSONDecodeError:
            transport = "human"
    if transport == "json":
        # terminal scalar leaves, multiline strings split into per-line units
        for match in re.finditer(r'"(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?|true|false|null', text):
            frag = match.group(0)
            if "\\n" in frag:
                offset = match.start()
                for piece in frag.split("\\n"):
                    if piece.strip(' "'):
                        units.append((offset, offset + len(piece)))
                    offset += len(piece) + 2
            elif frag.strip(' "'):
                units.append((match.start(), match.end()))
    else:
        offset = 0
        for line in text.splitlines(keepends=True):
            if line.strip():
                units.append((offset, offset + len(line.rstrip("\n"))))
            offset += len(line)
    return units


def support_spans(text: str, atoms: list[str]) -> list[tuple[int, int]]:
    spans = []
    for atom in atoms:
        start = 0
        while True:
            idx = text.find(atom, start)
            if idx < 0:
                break
            spans.append((idx, idx + len(atom)))
            start = idx + 1
    return spans


def phase_score(out: Path) -> None:
    sys.path.insert(0, "/tmp/ctxb/venv/lib/python3.14/site-packages")
    import tiktoken

    manifest = json.loads((out / "evaluation-manifest.json").read_text())
    enc = tiktoken.get_encoding(manifest["tokenizer"]["encoding"])
    records = json.loads((out / "run-records.json").read_text())
    raw = out / "raw"
    tasks = {t["task_id"]: t for t in manifest["tasks"]}

    per_invocation = []
    per_task = []

    grouped: dict[tuple[str, str, str], list[dict]] = {}
    for rec in records:
        grouped.setdefault((rec["binary"], rec["task_id"], rec["candidate"]), []).append(rec)

    for (binary, task_id, candidate), recs in sorted(grouped.items()):
        task = tasks[task_id]
        facts = task["required_facts"]
        accumulated = ""
        sufficient: set[str] = set()
        task_tokens = {"relevant-first": 0, "duplicate": 0, "irrelevant": 0}
        task_bytes = task_scalars = 0
        stderr_bytes = stderr_tokens = 0

        for rec in sorted(recs, key=lambda r: r["ordinal"]):
            stdout = (raw / rec["stdout_key"]).read_bytes()
            stderr = (raw / rec["stderr_key"]).read_bytes()
            stderr_bytes += len(stderr)
            stderr_tokens += len(enc.encode(stderr.decode("utf-8", "replace")))
            text = stdout.decode("utf-8", errors="replace")
            task_bytes += len(stdout)
            task_scalars += len(text)

            # per-invocation recall: facts fully supported by THIS stdout alone
            inv_supported = {
                f["id"]
                for f in facts
                if all(a in text for a in f["file_atoms"] + f["symbol_atoms"])
            }
            # annotate support spans, classify tokens
            before_sufficient = set(sufficient)
            accumulated += text
            newly = {
                f["id"]
                for f in facts
                if f["id"] not in sufficient
                and all(a in accumulated for a in f["file_atoms"] + f["symbol_atoms"])
            }
            sufficient |= newly

            spans_first: list[tuple[int, int]] = []
            spans_dup: list[tuple[int, int]] = []
            for f in facts:
                atoms = f["file_atoms"] + f["symbol_atoms"]
                sp = support_spans(text, atoms)
                if f["id"] in before_sufficient:
                    spans_dup.extend(sp)
                else:
                    spans_first.extend(sp)

            counts = {"relevant-first": 0, "duplicate": 0, "irrelevant": 0}
            offset = 0
            for token in enc.encode(text):
                piece = enc.decode([token])
                start, end = offset, offset + len(piece)
                offset = end
                if any(s < end and start < e for s, e in spans_first):
                    counts["relevant-first"] += 1
                elif any(s < end and start < e for s, e in spans_dup):
                    counts["duplicate"] += 1
                else:
                    counts["irrelevant"] += 1
            for k in counts:
                task_tokens[k] += counts[k]

            units = evidence_units(stdout, rec["transport"])
            all_spans = spans_first + spans_dup
            relevant_units = sum(
                1 for (us, ue) in units if any(s < ue and us < e for s, e in all_spans)
            )
            total_tokens = sum(counts.values())
            per_invocation.append(
                {
                    "binary": binary,
                    "task_id": task_id,
                    "candidate": candidate,
                    "ordinal": rec["ordinal"],
                    "node": rec["node"],
                    "transport": rec["transport"],
                    "argv": rec["argv"],
                    "exit_code": rec["exit_code"],
                    "duration_ns": rec["duration_ns"],
                    "stdout_bytes": len(stdout),
                    "stdout_scalars": len(text),
                    "stdout_tokens": total_tokens,
                    "stderr_bytes": len(stderr),
                    "recall": round(len(inv_supported) / len(facts), 6),
                    "evidence_units": len(units),
                    "evidence_unit_precision": round(relevant_units / len(units), 6) if units else 0.0,
                    "token_classes": counts,
                    "token_precision": round(
                        (counts["relevant-first"] + counts["duplicate"]) / total_tokens, 6
                    )
                    if total_tokens
                    else 0.0,
                }
            )

        total = sum(task_tokens.values())
        per_task.append(
            {
                "binary": binary,
                "task_id": task_id,
                "repository_id": task["repository_id"],
                "task_class": task["task_class"],
                "candidate": candidate,
                "required_facts": len(facts),
                "supported_facts": sorted(sufficient),
                "recall": round(len(sufficient) / len(facts), 6),
                "invocations": len(recs),
                "stdout_bytes": task_bytes,
                "stdout_scalars": task_scalars,
                "stdout_tokens": total,
                "stderr_bytes": stderr_bytes,
                "stderr_tokens": stderr_tokens,
                "token_classes": task_tokens,
                "token_precision": round(
                    (task_tokens["relevant-first"] + task_tokens["duplicate"]) / total, 6
                )
                if total
                else 0.0,
                "duplication_rate": round(task_tokens["duplicate"] / total, 6) if total else 0.0,
            }
        )

    # per-stratum micro averages
    strata: dict[tuple, dict] = {}
    for row in per_task:
        key = (row["binary"], row["candidate"], row["repository_id"], row["task_class"])
        acc = strata.setdefault(
            key,
            {
                "binary": row["binary"],
                "candidate": row["candidate"],
                "repository_id": row["repository_id"],
                "task_class": row["task_class"],
                "recall_num": 0, "recall_den": 0,
                "tok_num": 0, "tok_den": 0,
                "stdout_tokens": 0, "stdout_bytes": 0, "invocations": 0,
            },
        )
        acc["recall_num"] += len(row["supported_facts"])
        acc["recall_den"] += row["required_facts"]
        acc["tok_num"] += row["token_classes"]["relevant-first"] + row["token_classes"]["duplicate"]
        acc["tok_den"] += row["stdout_tokens"]
        acc["stdout_tokens"] += row["stdout_tokens"]
        acc["stdout_bytes"] += row["stdout_bytes"]
        acc["invocations"] += row["invocations"]
    per_stratum = []
    for key in sorted(strata):
        a = strata[key]
        per_stratum.append(
            {
                **{k: a[k] for k in ("binary", "candidate", "repository_id", "task_class")},
                "recall": round(a["recall_num"] / a["recall_den"], 6) if a["recall_den"] else 0.0,
                "token_precision": round(a["tok_num"] / a["tok_den"], 6) if a["tok_den"] else 0.0,
                "stdout_tokens": a["stdout_tokens"],
                "stdout_bytes": a["stdout_bytes"],
                "invocations": a["invocations"],
            }
        )

    # candidate roll-up (micro average across all development tasks)
    roll: dict[tuple[str, str], dict] = {}
    for row in per_task:
        acc = roll.setdefault(
            (row["binary"], row["candidate"]),
            {"recall_num": 0, "recall_den": 0, "tok_num": 0, "tok_den": 0,
             "dup": 0, "tokens": 0, "bytes": 0, "scalars": 0, "invocations": 0},
        )
        acc["recall_num"] += len(row["supported_facts"])
        acc["recall_den"] += row["required_facts"]
        acc["tok_num"] += row["token_classes"]["relevant-first"] + row["token_classes"]["duplicate"]
        acc["tok_den"] += row["stdout_tokens"]
        acc["dup"] += row["token_classes"]["duplicate"]
        acc["tokens"] += row["stdout_tokens"]
        acc["bytes"] += row["stdout_bytes"]
        acc["scalars"] += row["stdout_scalars"]
        acc["invocations"] += row["invocations"]
    per_candidate = []
    for (binary, candidate) in sorted(roll):
        a = roll[(binary, candidate)]
        per_candidate.append(
            {
                "binary": binary,
                "candidate": candidate,
                "recall": round(a["recall_num"] / a["recall_den"], 6),
                "token_precision": round(a["tok_num"] / a["tok_den"], 6) if a["tok_den"] else 0.0,
                "duplication_rate": round(a["dup"] / a["tokens"], 6) if a["tokens"] else 0.0,
                "stdout_tokens": a["tokens"],
                "stdout_bytes": a["bytes"],
                "stdout_scalars": a["scalars"],
                "invocations": a["invocations"],
            }
        )

    (out / "results.json").write_text(
        json.dumps(
            {
                "schema_version": 1,
                "manifest_sha256": sha256_bytes((out / "evaluation-manifest.json").read_bytes()),
                "per_candidate": per_candidate,
                "per_stratum": per_stratum,
                "per_task": per_task,
                "per_invocation": per_invocation,
            },
            indent=2,
        )
        + "\n"
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("phase", choices=["build", "run", "score", "all"])
    ap.add_argument("--out", default="/tmp/ctxb/eval/out")
    args = ap.parse_args()
    out = Path(args.out)
    if args.phase in ("build", "all"):
        phase_build(out)
        print("built manifest")
    if args.phase in ("run", "all"):
        phase_run(out)
        print("ran candidates")
    if args.phase in ("score", "all"):
        phase_score(out)
        print("scored")


if __name__ == "__main__":
    main()
