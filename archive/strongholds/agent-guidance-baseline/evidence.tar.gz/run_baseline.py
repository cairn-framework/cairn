#!/usr/bin/env python3
"""Run the development pilot without parsing or grading model output."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Iterable

PREPARATION_ROOT = Path("/tmp/cairn-agent-guidance-baseline")
DEFAULT_MANIFEST = PREPARATION_ROOT / "manifests" / "development.json"
DEFAULT_ORDER = PREPARATION_ROOT / "manifests" / "pilot-order.json"
CAIRN_BIN_DIR = Path("/Users/george/repos/cairn-loop/target/debug")
CAIRN_BIN = CAIRN_BIN_DIR / "cairn"
AUTH_SEED = PREPARATION_ROOT / "auth-seed"
SYSTEM_PROMPT = (
    "You are conducting a read-only codebase navigation study. "
    "Inspect the repository and answer the user's task directly. "
    "Do not modify files."
)
REQUIRED_ARMS = ("target", "cairn", "pack")
REQUIRED_TOOLS = ("read", "grep", "glob", "bash")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json_atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def load_manifest(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    if manifest.get("schema_version") != 1:
        raise ValueError("development manifest schema_version must be 1")
    settings = manifest.get("settings")
    tasks = manifest.get("tasks")
    if not isinstance(settings, dict) or not isinstance(tasks, list) or not tasks:
        raise ValueError("development manifest requires settings and non-empty tasks")
    if settings.get("pilot_trials") != 3:
        raise ValueError("development baseline requires exactly 3 pilot trials")
    if tuple(settings.get("arms", ())) != REQUIRED_ARMS:
        raise ValueError(f"arms must be exactly {list(REQUIRED_ARMS)}")
    if tuple(settings.get("tools", ())) != REQUIRED_TOOLS:
        raise ValueError(f"tools must be exactly {list(REQUIRED_TOOLS)}")
    for key in ("model", "thinking", "max_time", "randomization_seed"):
        if not settings.get(key):
            raise ValueError(f"development manifest setting {key!r} is required")
    seen_ids: set[str] = set()
    for task in tasks:
        if not isinstance(task, dict):
            raise ValueError("each task must be an object")
        required = ("id", "repository", "repo_sha", "task_class", "split", "prompt")
        missing = [key for key in required if not task.get(key)]
        if missing:
            raise ValueError(f"task is missing required fields: {missing}")
        if task["id"] in seen_ids:
            raise ValueError(f"duplicate task id: {task['id']}")
        seen_ids.add(task["id"])
        if task["split"] != "development":
            raise ValueError(f"non-development task in development manifest: {task['id']}")
    return manifest


def select_tasks(tasks: list[dict[str, Any]], filters: Iterable[str]) -> list[dict[str, Any]]:
    requested = [value.strip().lower() for value in filters if value.strip()]
    if not requested:
        raise ValueError("at least one --repo filter is required")

    def aliases(repository: str) -> set[str]:
        lowered = repository.lower()
        return {lowered, lowered.rsplit("/", 1)[-1]}

    available = {alias for task in tasks for alias in aliases(task["repository"])}
    unknown = sorted(set(requested) - available)
    if unknown:
        raise ValueError(f"unknown repository filter(s): {', '.join(unknown)}")
    selected = [
        task for task in tasks if any(value in aliases(task["repository"]) for value in requested)
    ]
    if not selected:
        raise ValueError("repository filters selected no tasks")
    return selected


def repository_slug(repository: str) -> str:
    return repository.rsplit("/", 1)[-1].lower()


def template_for(task: dict[str, Any], arm: str) -> Path:
    slug = repository_slug(task["repository"])
    if arm == "target":
        return PREPARATION_ROOT / "sources" / slug
    return PREPARATION_ROOT / "fixtures" / slug / arm


def source_for(task: dict[str, Any]) -> Path:
    return PREPARATION_ROOT / "sources" / repository_slug(task["repository"])


def resolve_git_dir(repository: Path) -> Path:
    dot_git = repository / ".git"
    if dot_git.is_dir():
        return dot_git
    if dot_git.is_file():
        line = dot_git.read_text(encoding="utf-8").strip()
        prefix = "gitdir: "
        if not line.startswith(prefix):
            raise ValueError(f"unrecognized .git file in {repository}")
        target = Path(line[len(prefix) :])
        return target if target.is_absolute() else (repository / target).resolve()
    raise ValueError(f"prepared source has no .git metadata: {repository}")


def read_git_head(repository: Path) -> str:
    git_dir = resolve_git_dir(repository)
    head = (git_dir / "HEAD").read_text(encoding="ascii").strip()
    if not head.startswith("ref: "):
        return head
    ref = head[5:]
    loose_ref = git_dir / ref
    if loose_ref.is_file():
        return loose_ref.read_text(encoding="ascii").strip()
    packed_refs = git_dir / "packed-refs"
    if packed_refs.is_file():
        for line in packed_refs.read_text(encoding="ascii").splitlines():
            if not line or line.startswith(("#", "^")):
                continue
            sha, name = line.split(" ", 1)
            if name == ref:
                return sha
    raise ValueError(f"cannot resolve {ref} in {repository}")


def validate_templates(tasks: list[dict[str, Any]]) -> None:
    checked_sources: set[Path] = set()
    checked_templates: set[Path] = set()
    for task in tasks:
        source = source_for(task)
        if source not in checked_sources:
            if not source.is_dir():
                raise ValueError(f"missing prepared source: {source}")
            actual_sha = read_git_head(source)
            if actual_sha != task["repo_sha"]:
                raise ValueError(
                    f"prepared source {source} is at {actual_sha}, "
                    f"expected {task['repo_sha']}"
                )
            checked_sources.add(source)
        for arm in REQUIRED_ARMS:
            template = template_for(task, arm)
            if template in checked_templates:
                continue
            if not template.is_dir():
                raise ValueError(f"missing prepared {arm} fixture: {template}")
            if arm == "pack" and not (template / ".cairn" / "AGENTS.md").is_file():
                raise ValueError(
                    f"pack guidance file is missing: {template}/.cairn/AGENTS.md"
                )
            checked_templates.add(template)
    if not CAIRN_BIN.is_file() or not os.access(CAIRN_BIN, os.X_OK):
        raise ValueError(f"pinned Cairn binary is not executable: {CAIRN_BIN}")


def arm_sort_key(seed: str, task_id: str, trial: int, arm: str) -> tuple[bytes, str]:
    material = f"{seed}\0{task_id}\0{trial}\0{arm}".encode("utf-8")
    return (hashlib.sha256(material).digest(), arm)


def expected_arm_order(seed: str, task_id: str, trial: int, arms: list[str]) -> list[str]:
    return sorted(arms, key=lambda arm: arm_sort_key(seed, task_id, trial, arm))


def load_pilot_order(path: Path, settings: dict[str, Any]) -> dict[str, Any]:
    if not path.is_file():
        raise ValueError(f"missing preregistered pilot order: {path}")
    with path.open("r", encoding="utf-8") as handle:
        order = json.load(handle)
    if order.get("schema_version") != 1:
        raise ValueError("pilot order schema_version must be 1")
    if order.get("seed") != settings["randomization_seed"]:
        raise ValueError("pilot order seed does not match development manifest")
    if order.get("pilot_trials") != settings["pilot_trials"]:
        raise ValueError("pilot order pilot_trials does not match development manifest")
    final_trials = order.get("final_trials")
    if final_trials is not None and final_trials != settings.get("final_trials"):
        raise ValueError("final order final_trials does not match development manifest")
    if tuple(order.get("arms", ())) != tuple(settings["arms"]):
        raise ValueError("pilot order arms do not match development manifest")
    algorithm = order.get("algorithm") or {}
    if algorithm.get("name") != "sha256-key-sort-v1":
        raise ValueError("pilot order algorithm must be sha256-key-sort-v1")
    blocks = order.get("orders")
    if not isinstance(blocks, list) or not blocks:
        raise ValueError("pilot order must include non-empty orders")
    for block in blocks:
        expected = expected_arm_order(
            settings["randomization_seed"],
            block["task_id"],
            block["trial"],
            list(settings["arms"]),
        )
        if list(block.get("arm_order", ())) != expected:
            raise ValueError(
                "pilot order arm_order mismatch for "
                f"{block['task_id']} trial {block['trial']}: "
                f"got {block.get('arm_order')}, expected {expected}"
            )
    return order


def expand_entries(
    pilot_order: dict[str, Any],
    tasks: list[dict[str, Any]],
    trial_filters: Iterable[int],
) -> list[dict[str, Any]]:
    tasks_by_id = {task["id"]: task for task in tasks}
    selected_ids = set(tasks_by_id)
    requested_trials = set(trial_filters)
    selected_trials = requested_trials or set(
        range(1, pilot_order["pilot_trials"] + 1)
    )
    available_trials = {
        block["trial"] for block in pilot_order["orders"]
    }
    unavailable_trials = sorted(selected_trials - available_trials)
    if unavailable_trials:
        raise ValueError(
            "order does not include requested trial(s): "
            + ", ".join(str(trial) for trial in unavailable_trials)
        )
    entries: list[dict[str, Any]] = []
    for block in pilot_order["orders"]:
        if block["trial"] not in selected_trials:
            continue
        task = tasks_by_id.get(block["task_id"])
        if task is None:
            if block["task_id"] in selected_ids:
                raise ValueError(f"missing task definition for {block['task_id']}")
            continue
        for arm in block["arm_order"]:
            entries.append(
                {
                    "position": len(entries) + 1,
                    "arm": arm,
                    "task_id": task["id"],
                    "task_class": task["task_class"],
                    "trial": block["trial"],
                    "repository": task["repository"],
                    "repo_sha": task["repo_sha"],
                }
            )
    expected_count = len(tasks) * len(selected_trials) * len(pilot_order["arms"])
    if len(entries) != expected_count:
        raise ValueError(
            "pilot order does not cover filtered tasks completely: "
            f"got {len(entries)} entries, expected {expected_count}"
        )
    return entries


def target_path(base_path: str) -> str:
    kept: list[str] = []
    pinned = CAIRN_BIN_DIR.resolve()
    for raw_entry in base_path.split(os.pathsep):
        if not raw_entry:
            continue
        entry = Path(raw_entry).expanduser()
        try:
            resolved = entry.resolve()
        except OSError:
            resolved = entry
        if resolved == pinned:
            continue
        candidate = entry / "cairn"
        if candidate.is_file() and os.access(candidate, os.X_OK):
            continue
        kept.append(raw_entry)
    return os.pathsep.join(kept)


def environment_for(arm: str, home_data_dir: Path) -> dict[str, str]:
    environment = os.environ.copy()
    without_cairn = target_path(environment.get("PATH", ""))
    environment["PATH"] = (
        without_cairn
        if arm == "target"
        else os.pathsep.join([str(CAIRN_BIN_DIR), without_cairn])
    )
    environment["PI_CODING_AGENT_DIR"] = str(home_data_dir)
    return environment


def pack_guidance_text(template: Path) -> str:
    agents_path = template / ".cairn" / "AGENTS.md"
    if not agents_path.is_file():
        raise ValueError(f"pack guidance file is missing: {agents_path}")
    return agents_path.read_text(encoding="utf-8")


def command_for(
    omp: Path,
    settings: dict[str, Any],
    arm: str,
    prompt: str,
    session_dir: Path,
    pack_guidance: str | None = None,
) -> list[str]:
    argv = [
        str(omp),
        "-p",
        "--mode=json",
        f"--model={settings['model']}",
        f"--thinking={settings['thinking']}",
        f"--max-time={settings['max_time']}",
        f"--tools={','.join(settings['tools'])}",
        f"--system-prompt={SYSTEM_PROMPT}",
        f"--session-dir={session_dir}",
        "--no-session",
        "--no-title",
        "--no-extensions",
        "--no-rules",
        "--auto-approve",
    ]
    if arm == "pack":
        if pack_guidance is None:
            raise ValueError("pack arm requires AGENTS.md guidance contents")
        argv.extend(
            [
                "--skills=cairn-*",
                f"--append-system-prompt={pack_guidance}",
            ]
        )
    else:
        argv.append("--no-skills")
    argv.append(prompt)
    return argv


def terminate_process(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=5)
        return
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait()


def execute_one(
    entry: dict[str, Any],
    task: dict[str, Any],
    settings: dict[str, Any],
    omp: Path,
    campaign_dir: Path,
    order_hash: str,
    phase: str,
) -> dict[str, Any]:
    run_id = (
        f"{entry['position']:03d}-{task['id'].lower()}-"
        f"trial-{entry['trial']}-{entry['arm']}"
    )
    run_dir = campaign_dir / "runs" / run_id
    cwd = run_dir / "cwd"
    session_dir = run_dir / "session"
    home_data_dir = run_dir / "home-data"
    raw_dir = run_dir / "raw"
    record_path = run_dir / "record.json"
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    template = template_for(task, entry["arm"])
    pack_guidance = pack_guidance_text(template) if entry["arm"] == "pack" else None
    run_dir.mkdir(parents=True)
    shutil.copytree(template, cwd, symlinks=True)
    session_dir.mkdir()
    home_data_dir.mkdir()
    shutil.copytree(AUTH_SEED, home_data_dir, dirs_exist_ok=True)
    raw_dir.mkdir()
    stdout_path = raw_dir / "stdout.bin"
    stderr_path = raw_dir / "stderr.bin"
    argv = command_for(
        omp,
        settings,
        entry["arm"],
        task["prompt"],
        session_dir,
        pack_guidance=pack_guidance,
    )
    environment = environment_for(entry["arm"], home_data_dir)

    started = time.monotonic_ns()
    timed_out = False
    exit_code: int | None = None
    runner_error: str | None = None
    with stdout_path.open("wb") as stdout_handle, stderr_path.open("wb") as stderr_handle:
        try:
            process = subprocess.Popen(
                argv,
                cwd=cwd,
                env=environment,
                stdin=subprocess.DEVNULL,
                stdout=stdout_handle,
                stderr=stderr_handle,
                start_new_session=True,
            )
            try:
                exit_code = process.wait(timeout=settings["max_time"])
            except subprocess.TimeoutExpired:
                timed_out = True
                terminate_process(process)
                exit_code = process.returncode
        except OSError as error:
            runner_error = f"{type(error).__name__}: {error}"
    ended = time.monotonic_ns()

    record = {
        "schema_version": 1,
        "arm": entry["arm"],
        "task_id": task["id"],
        "task_class": task["task_class"],
        "trial": entry["trial"],
        "phase": phase,
        "position": entry["position"],
        "repository": task["repository"],
        "repo_sha": task["repo_sha"],
        "pilot_order_sha256": order_hash,
        "argv": argv,
        "cwd": str(cwd),
        "session_dir": str(session_dir),
        "home_data_dir": str(home_data_dir),
        "path_environment": environment["PATH"],
        "started_monotonic_ns": started,
        "ended_monotonic_ns": ended,
        "duration_ns": ended - started,
        "exit_code": exit_code,
        "timed_out": timed_out,
        "runner_error": runner_error,
        "raw_stdout_path": str(stdout_path),
        "raw_stderr_path": str(stderr_path),
        "stdout_size_bytes": stdout_path.stat().st_size,
        "stderr_size_bytes": stderr_path.stat().st_size,
        "stdout_sha256": sha256_file(stdout_path),
        "stderr_sha256": sha256_file(stderr_path),
    }
    write_json_atomic(record_path, record)
    return {
        **record,
        "record_path": str(record_path),
        "record_sha256": sha256_file(record_path),
    }


def planned_run(
    entry: dict[str, Any],
    task: dict[str, Any],
    settings: dict[str, Any],
    omp: Path,
    campaign_dir: Path,
    phase: str,
) -> dict[str, Any]:
    run_id = (
        f"{entry['position']:03d}-{task['id'].lower()}-"
        f"trial-{entry['trial']}-{entry['arm']}"
    )
    run_dir = campaign_dir / "runs" / run_id
    cwd = run_dir / "cwd"
    session_dir = run_dir / "session"
    home_data_dir = run_dir / "home-data"
    template = template_for(task, entry["arm"])
    pack_guidance = pack_guidance_text(template) if entry["arm"] == "pack" else None
    environment = environment_for(entry["arm"], home_data_dir)
    return {
        **entry,
        "phase": phase,
        "template": str(template),
        "cwd": str(cwd),
        "session_dir": str(session_dir),
        "home_data_dir": str(home_data_dir),
        "path_environment": environment["PATH"],
        "argv": command_for(
            omp,
            settings,
            entry["arm"],
            task["prompt"],
            session_dir,
            pack_guidance=pack_guidance,
        ),
        "raw_stdout_path": str(run_dir / "raw" / "stdout.bin"),
        "raw_stderr_path": str(run_dir / "raw" / "stderr.bin"),
        "record_path": str(run_dir / "record.json"),
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest", type=Path, default=DEFAULT_MANIFEST, help=argparse.SUPPRESS
    )
    parser.add_argument(
        "--order", type=Path, default=DEFAULT_ORDER, help=argparse.SUPPRESS
    )
    parser.add_argument(
        "--repo",
        "--repo-filter",
        dest="repositories",
        action="append",
        required=True,
        metavar="OWNER/REPO|REPO",
        help="run only tasks for this repository; repeatable",
    )
    parser.add_argument(
        "--trial",
        dest="trials",
        action="append",
        type=int,
        default=[],
        metavar="N",
        help="run only this trial; repeatable",
    )
    parser.add_argument(
        "--phase",
        choices=("pilot", "final"),
        default="pilot",
        help="campaign phase recorded in run metadata (default: pilot)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="validate the selected order and print the plan without copying repos or invoking OMP",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    manifest_path = args.manifest.resolve()
    manifest = load_manifest(manifest_path)
    tasks = select_tasks(manifest["tasks"], args.repositories)
    validate_templates(tasks)
    manifest_hash = sha256_file(manifest_path)
    order_path = args.order.resolve()
    pilot_order = load_pilot_order(order_path, manifest["settings"])
    entries = expand_entries(pilot_order, tasks, args.trials)
    order_hash = sha256_file(order_path)
    omp_string = shutil.which("omp")
    if not omp_string:
        raise RuntimeError("omp executable is not available")
    omp = Path(omp_string).resolve()
    tasks_by_id = {task["id"]: task for task in tasks}
    campaign_id = (
        f"dry-run-{uuid.uuid4().hex}"
        if args.dry_run
        else time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + f"-{uuid.uuid4().hex}"
    )
    campaign_dir = PREPARATION_ROOT / "campaigns" / campaign_id

    if args.dry_run:
        plan = {
            "dry_run": True,
            "phase": args.phase,
            "manifest_path": str(manifest_path),
            "manifest_sha256": manifest_hash,
            "pilot_order_path": str(order_path),
            "pilot_order_sha256": order_hash,
            "campaign_dir": str(campaign_dir),
            "run_count": len(entries),
            "runs": [
                planned_run(
                    entry,
                    tasks_by_id[entry["task_id"]],
                    manifest["settings"],
                    omp,
                    campaign_dir,
                    args.phase,
                )
                for entry in entries
            ],
        }
        json.dump(plan, sys.stdout, indent=2, sort_keys=True)
        sys.stdout.write("\n")
        return 0

    campaign_dir.mkdir(parents=True, exist_ok=False)
    records = []
    for entry in entries:
        record = execute_one(
            entry,
            tasks_by_id[entry["task_id"]],
            manifest["settings"],
            omp,
            campaign_dir,
            order_hash,
            args.phase,
        )
        records.append(record)
        write_json_atomic(
            campaign_dir / "campaign.json",
            {
                "schema_version": 1,
                "phase": args.phase,
                "manifest_path": str(manifest_path),
                "manifest_sha256": manifest_hash,
                "pilot_order_path": str(order_path),
                "pilot_order_sha256": order_hash,
                "campaign_dir": str(campaign_dir),
                "records": records,
            },
        )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError) as error:
        print(f"run_baseline.py: {error}", file=sys.stderr)
        raise SystemExit(2)
